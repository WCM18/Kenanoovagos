<?php
/**
 * @author OnTheGo Systems
 */

class WPML_TM_ICL20MigrationException extends WPMLTranslationProxyApiException {
}
