<?php

interface IWPML_Translation_Roles_View {

	public function show( $model, $template );
}